@echo off
setlocal
cd /d "%~dp0"
title FaceLog - Daily Face Tracker
where node >nul 2>&1
if errorlevel 1 (
  echo Node.js ist nicht installiert.
  echo Bitte installiere Node.js LTS von https://nodejs.org/ und starte diese Datei erneut.
  pause
  exit /b 1
)
if not exist "node_modules\vite\bin\vite.js" (
  echo Installiere FaceLog-Abhaengigkeiten. Beim ersten Mal kann es etwas dauern...
  call npm install
  if errorlevel 1 (
    echo Installation fehlgeschlagen. Pruefe Internetverbindung und Node.js LTS.
    pause
    exit /b 1
  )
)
echo.
echo FaceLog startet. Oeffne die im Terminal angezeigte Adresse.
echo Zum Beenden STRG+C druecken.
call npm run dev
pause
