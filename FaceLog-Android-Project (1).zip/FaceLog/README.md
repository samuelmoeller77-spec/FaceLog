# FaceLog — Daily Face Tracker (Android + Web)

FaceLog ist eine eigenständige, mobile-first App für tägliche Gesichtsfotos, Verlauf und Vorher/Nachher-Vergleiche.

## Funktionen
- Ein Gesichts-Check-in pro Kalendertag (erneuter Upload ersetzt den Eintrag des Tages).
- MediaPipe Face Landmarker mit Messwerten und Bildqualitäts-Hinweisen.
- Erstes gespeichertes Foto = feste Baseline; neuestes Foto = aktuelles After.
- Verlauf, Vergleich nebeneinander oder als Overlay und JSON-Backup.
- Fotos und Messwerte werden lokal im Browser-/WebView-Speicher dieses Geräts gespeichert; kein Konto und kein eigener Backend-Server.
- PWA-Unterstützung und Android-Projektaufbau mit Capacitor.

## Android APK unter Windows erstellen

**Voraussetzungen:** Node.js LTS, Android Studio mit Android SDK und ein installiertes JDK (Android Studio bringt üblicherweise ein passendes JBR mit). Beim ersten Build wird Internet benötigt, damit Gradle und npm Pakete laden können.

1. Installiere Android Studio: https://developer.android.com/studio
2. Öffne Android Studio einmal und installiere über SDK Manager eine aktuelle Android SDK Platform sowie Android SDK Build-Tools. Akzeptiere die SDK-Lizenzen.
3. Stelle sicher, dass `ANDROID_HOME` oder `ANDROID_SDK_ROOT` auf deinen Android-SDK-Ordner zeigt (normalerweise `%LOCALAPPDATA%\Android\Sdk`).
4. Entpacke FaceLog und doppelklicke auf `build-apk-windows.bat`.
5. Beim ersten Lauf installiert das Skript npm-Abhängigkeiten, baut die Web-App, erzeugt das Android-Projekt und erstellt eine Debug-APK.
6. Die APK liegt nach erfolgreichem Build hier: `android\app\build\outputs\apk\debug\app-debug.apk`.
7. Übertrage `app-debug.apk` auf dein Android-Handy und öffne sie. Falls Android fragt, erlaube die Installation aus dieser Quelle.

### Manuell (optional)
Im Projektordner:

```bash
npm install
npm run build
npx cap add android
npx cap sync android
cd android
gradlew.bat assembleDebug
```

Falls `android` bereits existiert, `npx cap add android` überspringen.

## Lokal im Browser starten

```bash
npm install
npm run dev
```

## Fotos & Datenschutz
Die Fotos bleiben im lokalen Speicher dieses Geräts und dieser App-Installation. Sie werden nicht automatisch zwischen PC und Handy synchronisiert. Exportiere regelmäßig ein Backup und bewahre es privat auf. Deinstallation oder Löschen von App-Daten kann lokale Fotos entfernen.

## Hinweise zur Analyse
Werte sind Näherungen aus einem 2D-Foto, keine medizinische Diagnose oder objektive Attraktivitätsbewertung. Beleuchtung, Abstand, Ausdruck und Kopfhaltung beeinflussen die Messwerte. Das Face-Landmarker-Modell wird beim ersten Scan aus externen Quellen geladen, daher ist Internetzugang erforderlich.

## Build-Hinweis
Dieses ZIP enthält den Quellcode und den APK-Build-Ablauf. Eine fertige APK muss in einer Umgebung mit Android SDK/Gradle gebaut werden.
