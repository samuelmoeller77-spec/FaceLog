@echo off
setlocal
cd /d "%~dp0"
title FaceLog - Android APK Builder

where node >nul 2>&1
if errorlevel 1 (
  echo Node.js LTS fehlt. Installiere es von https://nodejs.org/
  pause
  exit /b 1
)
where npm >nul 2>&1
if errorlevel 1 (
  echo npm wurde nicht gefunden. Bitte Node.js LTS installieren.
  pause
  exit /b 1
)
if not exist "%ANDROID_HOME%" if not exist "%ANDROID_SDK_ROOT%" (
  echo Android SDK wurde ueber ANDROID_HOME/ANDROID_SDK_ROOT nicht gefunden.
  echo Installiere Android Studio und das Android SDK, starte danach dieses Skript erneut.
  echo Siehe README.md fuer die Schritte.
  pause
  exit /b 1
)
if not exist "node_modules\@capacitor\cli\dist\index.js" (
  echo Installiere JavaScript-Abhaengigkeiten...
  call npm install
  if errorlevel 1 goto failed
)
call npm run build
if errorlevel 1 goto failed
if not exist "android\gradlew.bat" (
  echo Erstelle das Android-Projekt...
  call npx cap add android
  if errorlevel 1 goto failed
)
call npx cap sync android
if errorlevel 1 goto failed
pushd android
call gradlew.bat assembleDebug
if errorlevel 1 (
  popd
  goto failed
)
popd
echo.
echo APK erfolgreich erstellt, falls der Build oben ohne Fehler endete:
echo %CD%\android\app\build\outputs\apk\debug\app-debug.apk
explorer "%CD%\android\app\build\outputs\apk\debug"
pause
exit /b 0
:failed
echo.
echo Build fehlgeschlagen. Lies die Fehlermeldung oben.
echo Pruefe Android Studio, SDK-Plattform, Internet und Java/JDK.
pause
exit /b 1
