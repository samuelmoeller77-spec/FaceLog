import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.facelog.daily',
  appName: 'FaceLog',
  webDir: 'dist',
};

export default config;
