@echo off
setlocal
cd /d "%~dp0"
title FaceLog - Build fuer Handy
where node >nul 2>&1
if errorlevel 1 (
  echo Bitte installiere Node.js LTS von https://nodejs.org/
  pause
  exit /b 1
)
if not exist "node_modules\vite\bin\vite.js" (
  call npm install
  if errorlevel 1 goto failed
)
call npm run build
if errorlevel 1 goto failed
echo.
echo Fertig! Der deploybare Web-App-Ordner ist: %CD%\dist
echo Lade den gesamten dist-Ordner auf https://app.netlify.com/drop hoch.
echo Oeffne danach die erzeugte HTTPS-Adresse auf deinem Handy.
pause
exit /b 0
:failed
echo Build fehlgeschlagen. Bitte die Fehlermeldung oben pruefen.
pause
exit /b 1
