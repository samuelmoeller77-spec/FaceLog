import { FaceLandmarker, FilesetResolver } from '@mediapipe/tasks-vision';

export type P = { x: number; y: number };
export type Metric = {
  key: string;
  label: string;
  value: string;
  score: number | null;
  confidence: number;
  hint: string;
  formula: string;
  lines: [number, number][];
};
export type QualityReport = {
  confidence: number;
  resolution: string;
  brightness: number;
  contrast: number;
  faceCoverage: number;
  roll: number;
  yaw: number;
  stability: number;
  warnings: string[];
};
export type Result = { metrics: Metric[]; overall: number | null; pts: P[]; quality: QualityReport; mode: 'front' | 'profile' };
export type ProgressUpdate = (percent: number, label: string) => void;

const dist = (a: P, b: P) => Math.hypot(a.x - b.x, a.y - b.y);
const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));
const avg = (xs: number[]) => xs.length ? xs.reduce((s, x) => s + x, 0) / xs.length : 0;
const radToDeg = (x: number) => x * 180 / Math.PI;

// A deliberately soft, non-clinical index. It never turns an out-of-band
// measurement into a zero and is explicitly not an attractiveness percentile.
function softIndex(value: number, low: number, high: number, tolerance: number) {
  const delta = value < low ? low - value : value > high ? value - high : 0;
  return Math.round(clamp(38 + 57 * Math.exp(-Math.pow(delta / Math.max(tolerance, 0.001), 1.25)), 38, 95));
}

let landmarker: FaceLandmarker | null = null;
let loadPromise: Promise<FaceLandmarker> | null = null;
async function getLandmarker() {
  if (landmarker) return landmarker;
  if (!loadPromise) {
    loadPromise = (async () => {
      const files = await FilesetResolver.forVisionTasks('https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.21/wasm');
      return FaceLandmarker.createFromOptions(files, {
        baseOptions: {
          modelAssetPath: 'https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task',
        },
        runningMode: 'IMAGE',
        numFaces: 1,
        outputFaceBlendshapes: false,
        outputFacialTransformationMatrixes: false,
      });
    })();
  }
  landmarker = await loadPromise;
  return landmarker;
}

function makeAnalysisImage(img: HTMLImageElement): HTMLCanvasElement {
  const maxDimension = 960;
  const factor = Math.min(1, maxDimension / Math.max(img.naturalWidth, img.naturalHeight));
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(img.naturalWidth * factor));
  c.height = Math.max(1, Math.round(img.naturalHeight * factor));
  const ctx = c.getContext('2d', { willReadFrequently: true });
  if (!ctx) throw new Error('CANVAS_UNAVAILABLE');
  ctx.drawImage(img, 0, 0, c.width, c.height);
  return c;
}

function measureImageQuality(img: HTMLImageElement) {
  const canvas = document.createElement('canvas');
  const scale = Math.min(1, 180 / Math.max(img.naturalWidth, img.naturalHeight));
  canvas.width = Math.max(1, Math.round(img.naturalWidth * scale));
  canvas.height = Math.max(1, Math.round(img.naturalHeight * scale));
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) throw new Error('CANVAS_UNAVAILABLE');
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  const pixels = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
  let sum = 0;
  let sumSq = 0;
  const count = pixels.length / 4;
  for (let i = 0; i < pixels.length; i += 4) {
    const y = 0.2126 * pixels[i] + 0.7152 * pixels[i + 1] + 0.0722 * pixels[i + 2];
    sum += y;
    sumSq += y * y;
  }
  const brightness = count ? sum / count : 0;
  const contrast = Math.sqrt(Math.max(0, sumSq / Math.max(1, count) - brightness * brightness));
  const minSide = Math.min(img.naturalWidth, img.naturalHeight);
  const resolutionFactor = clamp(minSide / 720, 0.35, 1);
  const brightnessFactor = clamp(1 - Math.abs(brightness - 130) / 135, 0.35, 1);
  const contrastFactor = clamp(contrast / 32, 0.4, 1);
  return {
    brightness,
    contrast,
    resolution: `${img.naturalWidth} × ${img.naturalHeight}`,
    resolutionFactor,
    brightnessFactor,
    contrastFactor,
  };
}

function waitForPaint() {
  return new Promise<void>((resolve) => requestAnimationFrame(() => resolve()));
}

function poseFromPoints(pts: P[], mode: 'front' | 'profile' = 'front') {
  const p = (n: number) => pts[n];
  const eyeLine = mode === 'front'
    ? Math.abs(radToDeg(Math.atan2(p(263).y - p(33).y, p(263).x - p(33).x)))
    : Math.abs(radToDeg(Math.atan2(p(152).x - p(10).x, p(152).y - p(10).y)));
  const leftToNose = dist(p(1), p(234));
  const rightToNose = dist(p(1), p(454));
  const yaw = Math.abs(leftToNose - rightToNose) / Math.max(1, leftToNose + rightToNose);
  return { roll: eyeLine, yaw };
}

function normalizedLandmarks(raw: Array<{ x: number; y: number }>, width: number, height: number): P[] {
  return raw.map((q) => ({ x: q.x * width, y: q.y * height }));
}

function stabilityScore(a: Array<{x:number;y:number}>, b: Array<{x:number;y:number}>) {
  const n = Math.min(468, a.length, b.length);
  if (n < 400) return 55;
  let total = 0;
  for (let i = 0; i < n; i++) total += Math.hypot(a[i].x - b[i].x, a[i].y - b[i].y) ** 2;
  const rms = Math.sqrt(total / n);
  return Math.round(clamp(100 - rms * 2200, 25, 100));
}

function buildQuality(img: HTMLImageElement, pts: P[], pixelQuality: ReturnType<typeof measureImageQuality>, stability: number, mode: 'front' | 'profile' = 'front'): QualityReport {
  const { roll, yaw } = poseFromPoints(pts, mode);
  const faceHeight = dist(pts[10], pts[152]);
  const faceCoverage = faceHeight / Math.max(1, img.naturalHeight);
  const warnings: string[] = [];
  if (Math.min(img.naturalWidth, img.naturalHeight) < 720) warnings.push('Niedrige Auflösung: kleine Details sind weniger verlässlich.');
  if (pixelQuality.brightness < 55) warnings.push('Das Foto ist dunkel; nutze weiches Licht von vorne.');
  if (pixelQuality.brightness > 205) warnings.push('Das Foto ist sehr hell; Highlights können Details verdecken.');
  if (pixelQuality.contrast < 17) warnings.push('Wenig Kontrast im Bild; bitte vor einem ruhigen, klaren Hintergrund aufnehmen.');
  if (faceCoverage < 0.28) warnings.push('Das Gesicht ist zu klein im Bild. Gehe etwas näher an die Kamera.');
  if (faceCoverage > 0.78) warnings.push('Das Gesicht ist stark angeschnitten oder zu nah an der Kamera.');
  if (mode === 'front' && roll > 5) warnings.push('Der Kopf ist seitlich geneigt; dadurch werden horizontale Verhältnisse ungenauer.');
  if (mode === 'profile' && roll > 10) warnings.push('Der Kopf ist seitlich gekippt; eine gerade Seitenaufnahme wäre verlässlicher.');
  if (mode === 'front' && yaw > 0.09) warnings.push('Das Bild wirkt nicht ganz frontal. Drehe das Gesicht zur Kamera und wiederhole den Scan.');
  if (mode === 'profile' && yaw < 0.12) warnings.push('Das Foto wirkt möglicherweise zu frontal. Für einen Profil-Check sollte die Nase klar im Seitenumriss liegen.');
  if (stability < 72) warnings.push('Die zwei Landmarken-Durchläufe stimmen nicht stabil genug überein. Ein klareres Foto wird empfohlen.');
  const faceCoverageFactor = clamp(faceCoverage < 0.3 ? faceCoverage / 0.3 : faceCoverage > 0.72 ? (0.9 - faceCoverage) / 0.18 : 1, 0.35, 1);
  const poseFactor = mode === 'front'
    ? clamp(1 - Math.max(0, roll - 2) / 24 - Math.max(0, yaw - 0.025) * 2.4, 0.35, 1)
    : clamp(1 - Math.max(0, roll - 10) / 32 - Math.max(0, 0.12 - yaw) * 2.5, 0.45, 1);
  const stabilityFactor = clamp(stability / 100, 0.35, 1);
  const confidence = Math.round(100 * pixelQuality.resolutionFactor * pixelQuality.brightnessFactor * pixelQuality.contrastFactor * faceCoverageFactor * poseFactor * stabilityFactor);
  return {
    confidence: clamp(confidence, 20, 98),
    resolution: pixelQuality.resolution,
    brightness: Math.round(pixelQuality.brightness),
    contrast: Math.round(pixelQuality.contrast),
    faceCoverage: Math.round(faceCoverage * 100),
    roll: Math.round(roll * 10) / 10,
    yaw: Math.round(yaw * 1000) / 1000,
    stability,
    warnings,
  };
}

function metric(key: string, label: string, value: string, score: number | null, confidence: number, hint: string, formula: string, lines: [number, number][]): Metric {
  return { key, label, value, score, confidence, hint, formula, lines };
}

function buildFrontMetrics(pts: P[], confidence: number): Metric[] {
  const p = (n: number) => pts[n];
  const d = (a: number, b: number) => dist(p(a), p(b));
  const faceW = d(234, 454);
  const faceH = d(10, 152);
  const eyeL = d(33, 133);
  const eyeR = d(263, 362);
  const meanEyeW = (eyeL + eyeR) / 2;
  const innerEyeGap = d(133, 362);
  const noseW = d(129, 358);
  const jawW = d(172, 397);
  const lowerH = d(2, 152);
  const faceHeightSafe = Math.max(1, faceH);
  const widthSafe = Math.max(1, faceW);
  const eyeSafe = Math.max(1, meanEyeW);
  const thirdsRaw = [d(10, 168), d(168, 2), d(2, 152)];
  const thirdsSum = thirdsRaw.reduce((s, x) => s + x, 0);
  const thirdsDeviation = avg(thirdsRaw.map((x) => Math.abs(x / Math.max(1, thirdsSum) - 1 / 3)));
  const lineA = p(10), lineB = p(152);
  const signedSide = (q: P) => ((lineB.x - lineA.x) * (q.y - lineA.y) - (lineB.y - lineA.y) * (q.x - lineA.x)) / faceHeightSafe;
  const mirroredPairs: [number, number][] = [[33, 263], [133, 362], [61, 291], [172, 397], [234, 454], [129, 358], [70, 300]];
  const symmetryDelta = avg(mirroredPairs.map(([l, r]) => Math.abs(Math.abs(signedSide(p(l))) - Math.abs(signedSide(p(r))))) ) / Math.max(0.1, faceW / faceH);
  const leftTilt = radToDeg(Math.atan2(p(33).y - p(133).y, Math.abs(p(33).x - p(133).x)));
  const rightTilt = radToDeg(Math.atan2(p(263).y - p(362).y, Math.abs(p(263).x - p(362).x)));
  const tiltDiff = Math.abs(leftTilt - rightTilt);
  const eyeSpacing = innerEyeGap / eyeSafe;
  const jawToCheek = jawW / widthSafe;
  const faceWidthHeight = faceW / faceHeightSafe;
  const noseToEyeGap = noseW / Math.max(1, innerEyeGap);
  const browSpan = d(70, 300) / widthSafe;
  const lowerShare = lowerH / faceHeightSafe;
  const confidenceFor = (factor: number) => Math.round(clamp(confidence * factor, 20, 98));
  const scoreable = (v: number) => Number.isFinite(v) && v >= 0 && v < 10;
  const mk = (key: string, label: string, value: number, fmt: string, score: number | null, hint: string, formula: string, lines: [number, number][], factor = 1) => { void value; return metric(key, label, fmt, score, confidenceFor(factor), hint, formula, lines); };

  return [
    mk('sym', 'Gesichtssymmetrie', symmetryDelta, `${(symmetryDelta * 100).toFixed(2)} % relative Abweichung`, scoreable(symmetryDelta) ? softIndex(symmetryDelta, 0, 0.025, 0.08) : null, 'Spiegelt links/rechts einige Landmarken entlang der mittleren Gesichtslinie. Kleine Unterschiede können von Mimik, Drehung und Perspektive kommen.', 'Mittlere Abweichung paariger Landmarken; kein klinischer oder Attraktivitätsstandard.', [[10, 152], [33, 263], [133, 362], [61, 291], [172, 397]], 0.95),
    mk('jaw', 'Kieferbreite', jawToCheek, `Kiefer / Wangenbreite ${jawToCheek.toFixed(3)}`, scoreable(jawToCheek) ? softIndex(jawToCheek, 0.68, 0.88, 0.2) : null, 'Vergleicht die erfasste Unterkieferbreite mit der Wangenbreite. Bart, Licht, Weichteile und Landmarks beeinflussen den Eindruck.', 'Abstand Landmarken 172–397 geteilt durch 234–454.', [[172, 397], [234, 454]], 0.88),
    mk('shape', 'Gesichtsform', faceWidthHeight, `Breite / Höhe ${faceWidthHeight.toFixed(3)}`, scoreable(faceWidthHeight) ? softIndex(faceWidthHeight, 0.62, 0.82, 0.22) : null, 'Beschreibt nur das sichtbare Verhältnis von Gesichtsbreite zu -höhe; es gibt keine universell beste Gesichtsform.', 'Wangenbreite 234–454 geteilt durch Höhe 10–152.', [[234, 454], [10, 152]], 0.9),
    mk('thirds', 'Gesichtsdrittel', thirdsDeviation, `Ø Abweichung ${(thirdsDeviation * 100).toFixed(2)} %`, scoreable(thirdsDeviation) ? softIndex(thirdsDeviation, 0, 0.035, 0.09) : null, 'Vergleicht drei Landmarken-Segmente grob miteinander. Haaransatz und Ausdruck sind in einer 2D-Aufnahme nicht sicher messbar.', 'Segmente 10–168, 168–2 und 2–152; nur grober Landmarken-Proxy.', [[10, 168], [168, 2], [2, 152]], 0.74),
    mk('eyes', 'Augenabstand', eyeSpacing, `Innerer Abstand / mittlere Augenbreite ${eyeSpacing.toFixed(3)}`, scoreable(eyeSpacing) ? softIndex(eyeSpacing, 0.7, 1.25, 0.45) : null, 'Beschreibt den Abstand zwischen inneren Augenwinkeln relativ zur durchschnittlichen Augenbreite; keine Aussage über „Hunter Eyes“.', 'Innerer Augenabstand 133–362 geteilt durch mittlere Augenbreite.', [[133, 362], [33, 133], [263, 362]], 0.91),
    mk('tilt', 'Augenlinien', tiltDiff, `Links/rechts Winkel-Differenz ${tiltDiff.toFixed(1)}°`, scoreable(tiltDiff) ? softIndex(tiltDiff, 0, 2.5, 10) : null, 'Zeigt den Unterschied der sichtbaren Augenlinien. Kein Score für Augentiefe, Augenhöhlenform oder die anatomische „Hunter-Eyes“-Kategorie.', 'Absolute Differenz der beiden Eckwinkel, 2D.', [[33, 133], [263, 362]], 0.84),
    mk('nose', 'Nasenbreite', noseToEyeGap, `Nasenbreite / innerer Augenabstand ${noseToEyeGap.toFixed(3)}`, scoreable(noseToEyeGap) ? softIndex(noseToEyeGap, 0.55, 1.05, 0.45) : null, 'Misst eine sichtbare 2D-Proportion. Kameradistanz und Weitwinkel können die Nase größer erscheinen lassen.', 'Nasenflügel-Abstand 129–358 geteilt durch inneren Augenabstand.', [[129, 358], [133, 362]], 0.77),
    mk('lower', 'Unteres Gesichtsdrittel', lowerShare, `Nase–Kinn / Gesichtshöhe ${lowerShare.toFixed(3)}`, scoreable(lowerShare) ? softIndex(lowerShare, 0.34, 0.52, 0.25) : null, 'Verhältnis einer groben unteren Gesichtshöhe; keine präzise Kiefer- oder Kinnprojektion.', 'Abstand 2–152 geteilt durch 10–152.', [[2, 152], [10, 152]], 0.76),
    mk('brow', 'Brauen-/Augenrahmen', browSpan, `Brauen-Landmarken-Spanne / Gesichtsbreite ${browSpan.toFixed(3)}`, scoreable(browSpan) ? softIndex(browSpan, 0.45, 0.78, 0.32) : null, 'Grobe Spanne ausgewählter Brauen-Landmarken. Styling und Haarwuchs sind hier nicht enthalten.', 'Abstand 70–300 geteilt durch Wangenbreite.', [[70, 300], [234, 454]], 0.65),
  ];
}

function buildProfileMetrics(pts: P[], confidence: number): Metric[] {
  const p = (n: number) => pts[n];
  const d = (a: number, b: number) => dist(p(a), p(b));
  const height = Math.max(1, d(10, 152));
  const horizontalNose = Math.abs(p(1).x - p(168).x) / height;
  const chinToLip = Math.abs(p(152).x - p(13).x) / height;
  const midX = (p(10).x + p(152).x) / 2;
  const noseOffset = Math.abs(p(1).x - midX) / height;
  const lowerShare = d(13, 152) / height;
  const cf = (factor: number) => Math.round(clamp(confidence * factor, 20, 98));
  const sc = (x: number) => Number.isFinite(x) && x >= 0 && x < 3;
  return [
    metric('profile', 'Profilbalance', `Nasenprojektion / Gesichtshöhe ${horizontalNose.toFixed(3)}`, sc(horizontalNose) ? softIndex(horizontalNose, 0.08, 0.2, 0.28) : null, cf(0.58), 'Ein 2D-Profil-Näherungswert. Kamera-Abstand, Kopfhaltung und Landmarkenfehler verändern ihn stark.', 'Horizontaler Versatz von Nasenspitze 1 zu Nasenwurzel-Proxy 168 / vertikale Gesichtshöhe.', [[1, 168], [10, 152]]),
    metric('chin', 'Kinn-/Lippenversatz', `Horizontaler Versatz / Gesichtshöhe ${chinToLip.toFixed(3)}`, sc(chinToLip) ? softIndex(chinToLip, 0.01, 0.12, 0.2) : null, cf(0.55), 'Keine medizinische Messung des Unterkiefers oder einer skelettalen Kinnprojektion.', 'Horizontaler Abstand 152–13 / Gesichtshöhe.', [[152, 13], [10, 152]]),
    metric('convexity', 'Profilkontur', `Nasenoffset / Gesichtshöhe ${noseOffset.toFixed(3)}`, sc(noseOffset) ? softIndex(noseOffset, 0.03, 0.16, 0.3) : null, cf(0.48), 'Beschreibt nur Landmarken-Positionen der sichtbaren Kontur. Kein cephalometrischer Winkel und keine Kieferdiagnose.', 'Abstand Nasenspitze zum Mittelpunkt der Linie Stirn–Kinn / Gesichtshöhe.', [[10, 1], [1, 152], [10, 152]]),
    metric('lower', 'Unteres Gesichtsdrittel', `Mund–Kinn / Gesichtshöhe ${lowerShare.toFixed(3)}`, sc(lowerShare) ? softIndex(lowerShare, 0.28, 0.43, 0.23) : null, cf(0.62), 'Grobe 2D-Proportion. Eine seitliche Aufnahme mit offenem Mund ist dafür ungeeignet.', 'Abstand 13–152 geteilt durch 10–152.', [[13, 152], [10, 152]]),
  ];
}

export async function analyze(img: HTMLImageElement, onProgress?: ProgressUpdate): Promise<Result | null> {
  if (!img.complete || !img.naturalWidth || !img.naturalHeight) throw new Error('IMAGE_NOT_READY');
  onProgress?.(4, 'Bildqualität und Auflösung prüfen');
  await waitForPaint();
  const pixelQuality = measureImageQuality(img);
  onProgress?.(18, 'Gesicht und Landmarken erkennen · Pass 1/2');
  await waitForPaint();
  const detector = await getLandmarker();
  const first = detector.detect(img).faceLandmarks[0];
  if (!first) return null;
  const firstPts = normalizedLandmarks(first, img.naturalWidth, img.naturalHeight);
  onProgress?.(48, '468+ Gesichtspunkte auflösen');
  await waitForPaint();
  const normalized = makeAnalysisImage(img);
  onProgress?.(62, 'Landmarken mit zweitem Durchlauf gegenprüfen');
  await waitForPaint();
  const second = detector.detect(normalized).faceLandmarks[0];
  const stability = second ? stabilityScore(first, second) : 45;
  const quality = buildQuality(img, firstPts, pixelQuality, stability);
  onProgress?.(80, 'Proportionen, Symmetrie und Winkel berechnen');
  await waitForPaint();
  const metrics = buildFrontMetrics(firstPts, quality.confidence);
  const valid = metrics.filter((m) => m.score !== null);
  const weighted = valid.reduce((s, m) => s + (m.score ?? 0) * Math.max(0.3, m.confidence / 100), 0);
  const weights = valid.reduce((s, m) => s + Math.max(0.3, m.confidence / 100), 0);
  const overall = valid.length ? Math.round(weighted / weights) : null;
  onProgress?.(96, 'Bericht auf Messbarkeit und Ausreißer prüfen');
  await waitForPaint();
  onProgress?.(100, 'Analysebericht fertig');
  return { metrics, overall, pts: firstPts, quality, mode: 'front' };
}

export async function analyzeProfile(img: HTMLImageElement, onProgress?: ProgressUpdate): Promise<Result | null> {
  if (!img.complete || !img.naturalWidth || !img.naturalHeight) throw new Error('IMAGE_NOT_READY');
  onProgress?.(4, 'Profilfoto und Bildqualität prüfen');
  await waitForPaint();
  const pixelQuality = measureImageQuality(img);
  onProgress?.(24, 'Gesichtslandmarken erkennen · Pass 1/2');
  await waitForPaint();
  const detector = await getLandmarker();
  const first = detector.detect(img).faceLandmarks[0];
  if (!first) return null;
  const firstPts = normalizedLandmarks(first, img.naturalWidth, img.naturalHeight);
  onProgress?.(56, 'Profilpunkte und sichtbare Kontur messen');
  await waitForPaint();
  const normalized = makeAnalysisImage(img);
  onProgress?.(70, 'Zweiten Landmarken-Durchlauf vergleichen');
  await waitForPaint();
  const second = detector.detect(normalized).faceLandmarks[0];
  const stability = second ? stabilityScore(first, second) : 45;
  const quality = buildQuality(img, firstPts, pixelQuality, stability, 'profile');
  const p = (n: number) => firstPts[n];
  const leftToNose = dist(p(1), p(234));
  const rightToNose = dist(p(1), p(454));
  const yaw = Math.abs(leftToNose - rightToNose) / Math.max(1, leftToNose + rightToNose);
  quality.yaw = Math.round(yaw * 1000) / 1000;
  quality.confidence = Math.round(clamp(quality.confidence, 20, 96));
  onProgress?.(88, 'Kinn, Nase und Profilverhältnisse berechnen');
  await waitForPaint();
  const metrics = buildProfileMetrics(firstPts, quality.confidence);
  const valid = metrics.filter((m) => m.score !== null);
  const overall = valid.length ? Math.round(valid.reduce((s, m) => s + (m.score ?? 0), 0) / valid.length) : null;
  onProgress?.(100, 'Profilbericht fertig');
  return { metrics, overall, pts: firstPts, quality, mode: 'profile' };
}

export function draw(c: HTMLCanvasElement, w: number, h: number, r: Result, sel: string) {
  c.width = w;
  c.height = h;
  const g = c.getContext('2d');
  if (!g) return;
  const k = w / 500;
  const P = r.pts;
  g.strokeStyle = 'rgba(155,123,255,.14)';
  g.lineWidth = k * 0.45;
  g.beginPath();
  for (const { start, end } of FaceLandmarker.FACE_LANDMARKS_TESSELATION) {
    if (P[start] && P[end]) { g.moveTo(P[start].x, P[start].y); g.lineTo(P[end].x, P[end].y); }
  }
  g.stroke();
  g.strokeStyle = '#9b7bff';
  g.lineWidth = k * 1.8;
  g.shadowColor = '#9b7bff';
  g.shadowBlur = k * 7;
  g.beginPath();
  for (const { start, end } of FaceLandmarker.FACE_LANDMARKS_FACE_OVAL) {
    if (P[start] && P[end]) { g.moveTo(P[start].x, P[start].y); g.lineTo(P[end].x, P[end].y); }
  }
  g.stroke();
  g.shadowBlur = 0;
  const ms = sel ? r.metrics.filter((x) => x.key === sel) : r.metrics;
  g.strokeStyle = '#5ef0c4';
  g.fillStyle = '#ffffff';
  g.lineWidth = k * (sel ? 2.4 : 1.15);
  for (const mt of ms) for (const [i, j] of mt.lines) {
    if (!P[i] || !P[j]) continue;
    g.beginPath(); g.moveTo(P[i].x, P[i].y); g.lineTo(P[j].x, P[j].y); g.stroke();
    for (const q of [P[i], P[j]]) { g.beginPath(); g.arc(q.x, q.y, k * (sel ? 3.2 : 2), 0, Math.PI * 2); g.fill(); }
  }
}
